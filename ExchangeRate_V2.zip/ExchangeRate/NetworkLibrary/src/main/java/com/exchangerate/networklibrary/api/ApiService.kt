package com.exchangerate.networklibrary.api

import com.exchangerate.networklibrary.BuildConfig
import com.exchangerate.networklibrary.model.ExchangeRateResponse
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*


interface ApiService {

    @GET(BuildConfig.URL_GET_EXCHANGE_RATE)
    suspend fun getExchangeRate(@Path("currency") accountId: String,
                                @Path("apiKey") apiKey: String): Response<ExchangeRateResponse>

}