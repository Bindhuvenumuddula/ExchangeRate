package com.exchangerate.networklibrary.di

import com.exchangerate.networklibrary.api.ApiService
import com.exchangerate.networklibrary.coroutines.DefaultDispatcherProvider
import com.exchangerate.networklibrary.coroutines.DispatcherProvider
import com.exchangerate.networklibrary.BuildConfig
import com.exchangerate.networklibrary.datasource.ExchangeDataSource
import com.exchangerate.networklibrary.datasource.ExchangeDataSourceImpl
import com.exchangerate.networklibrary.repository.ExchangeRepository
import com.exchangerate.networklibrary.repository.ExchangeRepositoryImpl
import dagger.Module
import dagger.Provides
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import javax.inject.Singleton
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    fun provideBaseUrl() = BuildConfig.BASE_URL

    @Provides
    @Singleton
    fun provideOkHttpClient() = if (BuildConfig.DEBUG) {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()
    } else OkHttpClient
        .Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()


    @Provides
    @Singleton
    fun provideRetrofit(
        okHttpClient: OkHttpClient,
        BASE_URL: String
    ): Retrofit =
        Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .build()

    @Provides
    @Singleton
    fun provideApiService(retrofit: Retrofit): ApiService = retrofit.create(ApiService::class.java)

    @Provides
    @Singleton
    fun provideAuthenticationDataSource(exchangeDataSourceImpl: ExchangeDataSourceImpl): ExchangeDataSource =
        exchangeDataSourceImpl



    @Provides
    @Singleton
    fun provideExchangeRepository(
        dispatcherProvider: DispatcherProvider,
        exchangeDataSource: ExchangeDataSource,
    ): ExchangeRepository {
        return ExchangeRepositoryImpl(dispatcherProvider, exchangeDataSource)
    }

    @Provides
    @Singleton
    internal fun provideDispatcherProvider(): DispatcherProvider = DefaultDispatcherProvider()

}