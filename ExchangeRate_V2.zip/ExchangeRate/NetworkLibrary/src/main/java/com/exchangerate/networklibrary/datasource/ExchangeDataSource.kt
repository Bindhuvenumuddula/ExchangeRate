package com.exchangerate.networklibrary.datasource

import com.exchangerate.networklibrary.model.ExchangeRateResponse
import com.exchangerate.networklibrary.utils.NetworkStatus
import okhttp3.RequestBody
import retrofit2.http.Body

interface ExchangeDataSource {

    suspend fun getExchangeRate(
        currency: String,
        apiKey: String
    ): NetworkStatus<ExchangeRateResponse>

}