package com.exchangerate.networklibrary.datasource

import com.exchangerate.networklibrary.model.ExchangeRateResponse
import com.exchangerate.networklibrary.api.ApiService
import com.exchangerate.networklibrary.utils.NetworkStatus
import com.exchangerate.networklibrary.utils.safeApiCall
import okhttp3.RequestBody
import javax.inject.Inject


class ExchangeDataSourceImpl @Inject constructor(private val apiService: ApiService) :
    ExchangeDataSource {

    override suspend fun getExchangeRate(
        currency: String,
        apiKey: String
    ): NetworkStatus<ExchangeRateResponse> {
        return safeApiCall {apiService.getExchangeRate(currency, apiKey)}
    }

}