package com.exchangerate.networklibrary.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}