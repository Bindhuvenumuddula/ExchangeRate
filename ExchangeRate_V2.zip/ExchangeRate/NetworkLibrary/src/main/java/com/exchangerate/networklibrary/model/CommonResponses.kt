package com.exchangerate.networklibrary.model

import com.google.gson.JsonElement
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class ExchangeRateResponse {
    @SerializedName("result")
    @Expose
    var result: String? = null

    @SerializedName("documentation")
    @Expose
    var documentation: String? = null

    @SerializedName("terms_of_use")
    @Expose
    var termsOfUse: String? = null

    @SerializedName("time_last_update_unix")
    @Expose
    var timeLastUpdateUnix: Int? = null

    @SerializedName("time_last_update_utc")
    @Expose
    var timeLastUpdateUtc: String? = null

    @SerializedName("time_next_update_unix")
    @Expose
    var timeNextUpdateUnix: Int? = null

    @SerializedName("time_next_update_utc")
    @Expose
    var timeNextUpdateUtc: String? = null

    @SerializedName("base_code")
    @Expose
    var baseCode: String? = null

    /*@SerializedName("conversion_rates")
    @Expose
    var conversionRates: ConversionRates? = null*/

    @SerializedName("conversion_rates")
    @Expose
    var conversionRates: JsonElement? = null
}


class ConversionRates {
    @get:SerializedName("AWG")
    @SerializedName("USD")
    @Expose
    var usd: Int? = null

    @SerializedName("AED")
    @Expose
    var aed: Double? = null

    @SerializedName("AFN")
    @Expose
    var afn: Double? = null

    @SerializedName("ALL")
    @Expose
    var all: Double? = null

    @SerializedName("AMD")
    @Expose
    var amd: Double? = null

    @SerializedName("ANG")
    @Expose
    var ang: Double? = null

    @SerializedName("AOA")
    @Expose
    var aoa: Double? = null

    @SerializedName("ARS")
    @Expose
    var ars: Double? = null

    @SerializedName("AUD")
    @Expose
    var aud: Double? = null

}





