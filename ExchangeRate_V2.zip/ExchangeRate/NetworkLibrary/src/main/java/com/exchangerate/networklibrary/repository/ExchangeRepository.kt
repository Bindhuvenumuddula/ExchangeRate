package com.exchangerate.networklibrary.repository

import com.exchangerate.networklibrary.model.ExchangeRateResponse
import com.exchangerate.networklibrary.utils.NetworkStatus
import okhttp3.RequestBody
import retrofit2.http.Body

interface ExchangeRepository {

    suspend fun getExchangeRate(
        currency: String
    ): NetworkStatus<ExchangeRateResponse>

}