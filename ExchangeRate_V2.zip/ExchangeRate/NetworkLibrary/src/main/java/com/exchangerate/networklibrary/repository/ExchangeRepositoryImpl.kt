package com.exchangerate.networklibrary.repository

import com.exchangerate.networklibrary.BuildConfig
import com.exchangerate.networklibrary.model.ExchangeRateResponse
import com.exchangerate.networklibrary.coroutines.DispatcherProvider
import com.exchangerate.networklibrary.datasource.ExchangeDataSource
import com.exchangerate.networklibrary.utils.NetworkStatus
import kotlinx.coroutines.withContext
import okhttp3.RequestBody
import retrofit2.http.Body
import javax.inject.Inject

class ExchangeRepositoryImpl @Inject constructor(
    private val dispatcherProvider: DispatcherProvider,
    private val exchangeDataSource: ExchangeDataSource
    ) : ExchangeRepository {

    override suspend fun getExchangeRate(
        currency: String
    ): NetworkStatus<ExchangeRateResponse> {

        return withContext(dispatcherProvider.io()) { exchangeDataSource.getExchangeRate(currency, BuildConfig.EXCHANGE_RATE_API_KEY) }
    }
}