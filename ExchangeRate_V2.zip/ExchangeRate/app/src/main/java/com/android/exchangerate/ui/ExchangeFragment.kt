package com.android.exchangerate.ui

import APPROVAL_DURATION
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.android.exchangerate.R
import com.android.exchangerate.databinding.FragmentExchangeBinding
import com.android.exchangerate.utils.DialogListener
import com.android.exchangerate.utils.showCustomDialog
import com.android.exchangerate.viewmodel.ExchangeViewModel


/**
 * A simple [Fragment] subclass.
 * Use the [ExchangeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ExchangeFragment : Fragment() {

    private lateinit var exchangeViewModel: ExchangeViewModel
    private lateinit var dataBinding: FragmentExchangeBinding

    private var conversationApproved: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_home, container, false)
        dataBinding = FragmentExchangeBinding.inflate(inflater, container, false)
        exchangeViewModel =
            ViewModelProvider(requireActivity()).get(ExchangeViewModel::class.java)
        dataBinding.viewModel = exchangeViewModel

        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val fromAmount = "${exchangeViewModel.amountView.get()} ${exchangeViewModel.fromCurrencyView.get()}"
        dataBinding.txtFromCurrency.text = fromAmount

        exchangeViewModel.amountView.get()?.let {
            val resultAmount = "${it.toDouble() * exchangeViewModel.toConversationRate} ${exchangeViewModel.toCurrencyView.get()}"
            dataBinding.txtToCurrency.text = resultAmount
        }

        object : CountDownTimer(APPROVAL_DURATION, 1000) {
            override fun onTick(millisUntilFinished: Long) {

                val progress = (millisUntilFinished / 1000).toInt()

                //progressBar.setProgress(progressBar.getMax() - progress)
                dataBinding.txtTimer.setText("${progress}")

            }

            override fun onFinish() {
                if(!conversationApproved) {
                    //show message
                }
            }
        }.start()

        dataBinding.btnConvert.setOnClickListener {
            val msg = getString(R.string.str_approve_msg, dataBinding.txtFromCurrency.text.toString(), dataBinding.txtToCurrency.text.toString())
           showApproveDialog(msg)
        }
    }

    private fun showApproveDialog(message: String) {

        activity?.let { context ->

            context.showCustomDialog(
                title = context.getString(R.string.string_approval_required),
                message = message,
                positiveTitle = context.getString(R.string.str_approve),
                negativeTitle = context.getString(R.string.str_cancel),
                dialogListener = object : DialogListener {
                    override fun onPositiveClick() {
                        conversationApproved = true
                        findNavController()
                            .navigate(R.id.action_exchangeFragment_to_exchangeResultFragment)
                    }

                    override fun onNegativeClick() {

                    }

                    override fun onDismissListener() {

                    }
                }
            )
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @return A new instance of fragment ExchangeFragment.
         */
        @JvmStatic
        fun newInstance() =
            ExchangeFragment().apply {
                arguments = Bundle().apply {

                }
            }
    }
}