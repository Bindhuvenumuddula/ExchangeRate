package com.android.exchangerate.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.android.exchangerate.R
import com.android.exchangerate.databinding.FragmentHomeBinding
import com.android.exchangerate.viewmodel.ExchangeViewModel
import com.exchangerate.networklibrary.utils.Status
import com.tiper.MaterialSpinner

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class HomeFragment : Fragment() {

    private lateinit var exchangeViewModel: ExchangeViewModel
    private lateinit var dataBinding: FragmentHomeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_home, container, false)
        dataBinding = FragmentHomeBinding.inflate(inflater, container, false)
        exchangeViewModel =
            ViewModelProvider(requireActivity()).get(ExchangeViewModel::class.java)
        dataBinding.viewModel = exchangeViewModel

        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadFromCurrency()
        loadToCurrency()
    }

    private fun loadFromCurrency() {
        activity?.let {
            ArrayAdapter.createFromResource(
                it.baseContext,
                R.array.array_currency,
                android.R.layout.simple_spinner_item
            ).let {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                dataBinding.ctmsFromCountry.apply {
                    adapter = it
                    onItemSelectedListener = fromCurrencyListener
                    onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                    }
                    selection = 0
                }

            }
        }
    }

    private val fromCurrencyListener by lazy {
        object : MaterialSpinner.OnItemSelectedListener {
            override fun onItemSelected(
                parent: MaterialSpinner,
                view: View?,
                position: Int,
                id: Long
            ) {
                exchangeViewModel.fromCurrencyView.set(dataBinding.ctmsFromCountry.selectedItem.toString())
            }

            override fun onNothingSelected(parent: MaterialSpinner) {

            }
        }
    }

    private fun loadToCurrency() {
        activity?.let {
            ArrayAdapter.createFromResource(
                it.baseContext,
                R.array.array_currency,
                android.R.layout.simple_spinner_item
            ).let {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                dataBinding.ctmsToCountry.apply {
                    adapter = it
                    onItemSelectedListener = toCurrencyListener
                    onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                    }
                    selection = 0
                }

            }
        }
    }

    private val toCurrencyListener by lazy {
        object : MaterialSpinner.OnItemSelectedListener {
            override fun onItemSelected(
                parent: MaterialSpinner,
                view: View?,
                position: Int,
                id: Long
            ) {
                exchangeViewModel.toCurrencyView.set(dataBinding.ctmsToCountry.selectedItem.toString())
            }

            override fun onNothingSelected(parent: MaterialSpinner) {

            }
        }
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @return A new instance of fragment HomeFragment.
         */
        @JvmStatic
        fun newInstance() =
            HomeFragment().apply {

            }
    }
}