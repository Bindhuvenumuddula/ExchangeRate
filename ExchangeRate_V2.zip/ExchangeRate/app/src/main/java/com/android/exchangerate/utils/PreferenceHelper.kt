package com.android.exchangerate.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import timber.log.Timber

data class PreferenceHelper(private var applicationContext: Context? = null) {

    companion object {
        lateinit var preference: SharedPreferences
        private var preferenceHelper = PreferenceHelper()
        fun getPreferenceHelper(): PreferenceHelper {
            if (preferenceHelper.applicationContext == null) {
                Timber.d("Please set setPreferenceHelper before calling this method")
                //throw "Please set setPreferenceHelper before calling this method"
            }
            return preferenceHelper
        }

        fun setPreferenceHelper(context: Context) {
            this.preferenceHelper.apply {
                applicationContext = context.applicationContext
            }
            preference = PreferenceManager.getDefaultSharedPreferences(context.applicationContext)
            //preferenceHelper.applicationContext=context.applicationContext
        }
    }

    fun getString(key: String) = preference.getString(key, "").toString()

    fun getInt(key: String) = preference.getInt(key, 0)

    fun getLong(key: String) = preference.getLong(key, 0)
    fun getLong(key: String, defaultValue: Long) = preference.getLong(key, defaultValue)

    fun getFloat(key: String) = preference.getFloat(key, 0.0F)

    fun getBoolean(key: String) = preference.getBoolean(key, false)

    fun setString(key: String, data: String) {
        preference.edit().putString(key, data).apply()
    }

    fun setInt(key: String, data: Int) {
        preference.edit().putInt(key, data).apply()
    }

    fun setLong(key: String, data: Long) {
        preference.edit().putLong(key, data).apply()
    }

    fun setFloat(key: String, data: Float) {
        preference.edit().putFloat(key, data).apply()
    }

    fun setBoolean(key: String, data: Boolean) {
        preference.edit().putBoolean(key, data).apply()
    }

    fun remove(key: String) {
        preference.edit().remove(key).apply()
    }

}