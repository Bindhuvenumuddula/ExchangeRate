package com.android.exchangerate.viewmodel

import android.content.Context
import android.view.View
import android.widget.Toast
import androidx.databinding.ObservableField
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.android.exchangerate.R
import com.android.exchangerate.utils.NetworkHelper
import com.android.exchangerate.utils.hideDialog
import com.android.exchangerate.utils.showDialog
import com.android.exchangerate.utils.showInternetDialog
import com.exchangerate.networklibrary.model.ExchangeRateResponse
import com.exchangerate.networklibrary.repository.ExchangeRepository
import com.exchangerate.networklibrary.utils.NetworkStatus
import com.exchangerate.networklibrary.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.lang.Exception
import java.util.*
import javax.inject.Inject


@HiltViewModel
class ExchangeViewModel @Inject constructor(
    private val exchangeRepository: ExchangeRepository,
    private val networkHelper: NetworkHelper
) : ViewModel() {

    var fromCurrencyView: ObservableField<String> = ObservableField()
    var toCurrencyView: ObservableField<String> = ObservableField()
    var amountView: ObservableField<String> = ObservableField()
    var fromRate : Double = 0.0
    var toConversationRate : Double = 0.0

    fun onBackButtonClick(view: View){
        view.findNavController().popBackStack()
    }

    fun onHomeClick(view: View){
        view.findNavController().navigate(R.id.action_exchangeResultFragment_to_homeFragment)
    }

    fun onCalculateClick(view: View) {

        val fromCurrencyValue = fromCurrencyView.get() ?: ""
        val toCurrencyValue = toCurrencyView.get() ?: ""
        val amountValue = amountView.get() ?: ""

        if(amountValue.isEmpty()){
            Toast.makeText(view.context, "Please enter amount to convert", Toast.LENGTH_LONG).show()
        }else{
            viewModelScope.launch {
                calculateCurrency(view, view.context, fromCurrencyValue, toCurrencyValue)
            }
        }
    }


    private suspend fun calculateCurrency(view: View, context: Context, fromCurrency: String, toCurrency: String) {

        viewModelScope.launch {
            if (networkHelper.isNetworkConnected()) {
                withContext(Dispatchers.Main) {
                    context.showDialog()
                }

                exchangeRepository.getExchangeRate(fromCurrency).let { response ->
                    Timber.d("Exchange Rate Result ${response.data?.conversionRates}")
                    withContext(Dispatchers.Main) {
                        context.hideDialog()
                    }

                    when (response) {

                        is NetworkStatus.Success -> {
                           // _exchangeRateInfo.postValue(Resource.success(response.data))

                            response.data?.let {

                                try {

                                    if (it.result.equals("success")) {
                                        it.conversionRates?.let { jsonElement ->
                                            if(jsonElement.isJsonObject){
                                                jsonElement.asJsonObject?.let { jsonObject ->
                                                    if(jsonObject.has(fromCurrency)){
                                                        fromRate = jsonObject.get(fromCurrency).asDouble
                                                    }
                                                    if(jsonObject.has(toCurrency)){
                                                         toConversationRate = jsonObject.get(toCurrency).asDouble
                                                    }
                                                }
                                            }
                                        }

                                        view.findNavController()
                                            .navigate(R.id.action_homeFragment_to_exchangeFragment)

                                    } else {
                                        //Toast.makeText(activity, it.message ?: "", Toast.LENGTH_LONG).show()
                                    }

                                }catch (ex: Exception){

                                }

                            }
                        }
                        is NetworkStatus.Error -> {
                            if (response.errorMessage.isNullOrEmpty().not()) {
                                Toast.makeText(context, response.errorMessage ?: "", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Unknown error", Toast.LENGTH_LONG).show()
                            }
                        }
                        else -> {}
                    }
                }
            } else {
                context.showInternetDialog()
            }
        }
    }


}