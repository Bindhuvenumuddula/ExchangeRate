package com.android.exchangerate.ui

import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.android.exchangerate.R
import com.android.exchangerate.databinding.FragmentExchangeResultBinding
import com.android.exchangerate.viewmodel.ExchangeViewModel


/**
 * A simple [Fragment] subclass.
 * Use the [ExchangeResultFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ExchangeResultFragment : Fragment() {

    private lateinit var exchangeViewModel: ExchangeViewModel
    private lateinit var dataBinding: FragmentExchangeResultBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_home, container, false)
        dataBinding = FragmentExchangeResultBinding.inflate(inflater, container, false)
        exchangeViewModel =
            ViewModelProvider(requireActivity()).get(ExchangeViewModel::class.java)
        dataBinding.viewModel = exchangeViewModel

        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val fromAmount = "${exchangeViewModel.amountView.get()} ${exchangeViewModel.fromCurrencyView.get()}"
        val text = getString(R.string.great_now_you_have, fromAmount)
        dataBinding.txtFromCurrency.text = text

        dataBinding.txtConversationRate.text = "${exchangeViewModel.fromRate} / ${exchangeViewModel.toConversationRate}"

        handleBackpress()
    }

    private fun handleBackpress(){

        view?.apply {
            setFocusableInTouchMode(true)
            requestFocus()
            setOnKeyListener(object : View.OnKeyListener {
                override fun onKey(v: View?, keyCode: Int, event: KeyEvent?): Boolean {
                    return if (keyCode == KeyEvent.KEYCODE_BACK) {
                        true
                    } else false
                }
            })
        }

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @return A new instance of fragment ExchangeResultFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance() =
            ExchangeResultFragment().apply {
                arguments = Bundle().apply {
                }
            }
    }
}