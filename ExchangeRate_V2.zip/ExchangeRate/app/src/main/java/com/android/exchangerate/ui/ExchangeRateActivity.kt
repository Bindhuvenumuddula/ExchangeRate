package com.android.exchangerate.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.android.exchangerate.R
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ExchangeRateActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exchange_rate)
    }
}