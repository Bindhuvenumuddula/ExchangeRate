
//Preferences
const val APPROVAL_DURATION: Long = 30000

