package com.android.exchangerate.utils


import android.app.AlertDialog
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.view.View
import android.view.inputmethod.InputMethodManager
import dmax.dialog.SpotsDialog


var progressDialog: AlertDialog? = null

/**
 * Show progress dialog extension function
 * @param cancelable Boolean value indicate true or false
 * @param message String
 */
fun Context.showDialog(cancelable: Boolean = true, message: String = "Loading...") {
    progressDialog?.let {
        if (it.isShowing) {
            it.dismiss()
        }
        progressDialog = null
    }

    progressDialog =
        SpotsDialog.Builder().setContext(this)
            .setCancelable(cancelable)
            .setMessage(message)
            .build()

    progressDialog?.show()
}

/**
 * Hide progress dialog extension function
 */
fun Context.hideDialog() {
    progressDialog?.dismiss()
}


//Check internet extension function, return true if internet available else false
fun Context.haveNetwork(): Boolean {
    var result = false
    val connectivityManager =
        getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?

    connectivityManager?.let {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            it.getNetworkCapabilities(connectivityManager.activeNetwork)?.apply {
                result = when {
                    hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                    hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                    else -> false
                }
            }
        } else {
            val activeNetwork = connectivityManager.activeNetworkInfo
            activeNetwork?.let { network1 ->
                result = when (network1.type) {
                    ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE -> true
                    else -> false
                }

            }
        }
    }
    return result
}


/**
 * Hide keyboard extension function
 */
fun View.hideKeyboard() {
    try {
        val imm =
            this.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(this.windowToken, 0)
    } catch (ex: Exception) {
        ex.printStackTrace()
    }
}

fun View.openKeyboard() {
    try {
        this.requestFocus()
        val imm =
            this.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
    } catch (ex : Exception) {
        ex.printStackTrace()
    }
}