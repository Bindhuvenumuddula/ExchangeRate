package com.android.exchangerate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.android.exchangerate.ui.ExchangeRateActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({

            moveToNextScreen()

        }, 1000)
    }

    private fun moveToNextScreen() {
        val intent = Intent(this, ExchangeRateActivity::class.java)
        startActivity(intent)
        finish()
    }
}