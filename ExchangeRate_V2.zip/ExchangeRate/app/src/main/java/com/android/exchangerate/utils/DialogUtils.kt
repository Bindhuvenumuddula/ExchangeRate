package com.android.exchangerate.utils

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.view.isVisible
import com.android.exchangerate.R
import com.android.exchangerate.databinding.AppDialogBinding
import timber.log.Timber

// DialogListener interface
interface DialogListener {
    fun onPositiveClick()
    fun onNegativeClick()
    fun onDismissListener()
}

//Show no internet dialog extension function
fun Context.showInternetDialog() {
    showCustomDialog(
        message = getString(R.string.msg_no_internet),
        title = getString(R.string.str_alert)
    )
}

//Show Unknown error dialog extension function
fun Context.showUnknownError() {
    showCustomDialog(
        title = getString(R.string.str_unknown_error),
        message = getString(R.string.msg_error_null),
    )
}

/**
 * Show custom dialog alert extension function
 * @param message Dialog description
 * @param title Title of the dialog
 * @param positiveTitle Positive button title
 * @param negativeTitle Negative button title
 * @param dialogListener Interface for negative and cancel callback listener
 */
fun Context.showCustomDialog(
    title: String? = null,
    message: String?,
    positiveTitle: String? = null,
    negativeTitle: String? = null,
    dialogListener: DialogListener? = null,
    negativeTitleColor: Int? = null,
    isHideNegativeButton : Boolean? = false
) {

    val viewBinding = AppDialogBinding.inflate(LayoutInflater.from(this))
    val customDialog = AlertDialog.Builder(this)
        .setView(viewBinding.root)
        .setCancelable(false)
        .show()

    try {
        customDialog.window?.let {
            val window: Window = it
            val layoutParams = WindowManager.LayoutParams()
            layoutParams.copyFrom(window.attributes)
            val displayWidth: Int = this.resources.displayMetrics.widthPixels
            layoutParams.width = (displayWidth * 0.85).toInt()
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
            it.attributes = layoutParams
            it.setBackgroundDrawableResource(android.R.color.transparent)
        }
    } catch (e: Exception) {
        Timber.d("Exception : ${e.message}")
    }

    //set title for alert dialog
    title?.let {
        viewBinding.tvTitle.text = it
    } ?: run {
        viewBinding.tvTitle.text = getString(R.string.str_alert)
    }

    //set message for alert dialog
    viewBinding.tvMessage.text = message

    /* Set positive button text */
    positiveTitle?.let { buttonText ->
        viewBinding.positiveButton.text = buttonText
    } ?: run {
        viewBinding.positiveButton.text = getString(R.string.str_ok)
    }
    /* Set positive button functionality */
    viewBinding.positiveButton.setOnClickListener {
        dialogListener?.onPositiveClick()
        customDialog.dismiss()
    }

    /* Set negative button text */
    negativeTitle?.let { buttonText ->
        viewBinding.negativeButton.text = buttonText
    } ?: run {
        viewBinding.negativeButton.text = getString(R.string.str_cancel)
    }
    if(isHideNegativeButton == true){
        viewBinding.negativeButton.visibility = View.GONE
    }else{
        viewBinding.negativeButton.isVisible = dialogListener != null
        viewBinding.btnDivider.isVisible = dialogListener != null
    }

    /* Set negative button functionality */
    viewBinding.negativeButton.setOnClickListener {
        dialogListener?.onNegativeClick()
        customDialog.dismiss()
    }



    negativeTitleColor?.let {
        viewBinding.negativeButton.setTextColor(it)
    }

    customDialog.setOnDismissListener {
        dialogListener?.onDismissListener()
    }
}

