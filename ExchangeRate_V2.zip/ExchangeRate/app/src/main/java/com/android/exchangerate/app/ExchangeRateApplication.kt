package com.android.exchangerate.app

import android.content.Context
import androidx.multidex.MultiDexApplication
import com.android.exchangerate.BuildConfig
import com.android.exchangerate.utils.PreferenceHelper
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class ExchangeRateApplication : MultiDexApplication(){

    init {
        instance = this
    }

    companion object {

        private var instance: ExchangeRateApplication? = null

        fun applicationContext(): Context {
            return instance!!.applicationContext
        }
    }

    override fun onCreate() {
        super.onCreate()

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        PreferenceHelper.setPreferenceHelper(this)
    }
}